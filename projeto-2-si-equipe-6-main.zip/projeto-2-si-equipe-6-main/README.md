<h1 align="center" style="font-weight: bold;">Projetos - Grupo 6💻</h1>

<p align="center">
 <a href="#tech">Tecnologias</a> • 
 <a href="#colab">Colaboradores</a> •
 <a href="https://sites.google.com/d/15IcJs4e7vlrp8Ps8z03koREoM7PrZ-3h/p/1zr67In-LOZaGX0enF4LqhuruqwAHVQDz/edit">Google Sites</a> 
 
</p>

<p align="center">
    <b>Descrição em breve</b>
</p>

<h2 id="technologies">💻 Tecnologias</h2>

- Python
- Django
- MySQL
- Git
- HTML/CSS

<h2 id="colab">🤝 Colaboradores</h2>

Agradecimento especial para os que contribuiram para este projeto acontecer.

<table>
  <tr>
    <td align="center">
      <a href="#">
        <img src="https://github.com/user-attachments/assets/f0d4048a-922a-4ce2-9343-24d604825f45" width="100px;" alt="Foto de João Pedro"/><br>
        <sub>
          <b>Dácio Augusto</b>
        </sub>
      </a>
    </td>
    <td align="center">
      <a href="#">
        <img src="https://github.com/user-attachments/assets/14cdaefb-7f40-49a9-8d6f-26b3857fed92" width="100px;" alt="Foto de João Pedro"/><br>
        <sub>
          <b>João Pedro Gomes</b>
        </sub>
      </a>
    </td>
    <td align="center">
      <a href="#">
        <img src="https://github.com/user-attachments/assets/0262565e-a188-47a6-aaf2-9586205fbfc8" width="100px;" alt="Foto de Leo"/><br>
        <sub>
          <b>Leonardo Granja</b>
        </sub>
      </a>
    </td>
    <td align="center">
      <a href="#">
        <img src="https://github.com/user-attachments/assets/4c560164-49bd-4093-b63d-be1a0691437b" width="100px;" alt="Foto de Luca"/><br>
        <sub>
          <b>Luca Monteiro</b>
        </sub>
      </a>
    </td>
    <td align="center">
      <a href="#">
        <img src="https://github.com/user-attachments/assets/e3763f87-1db5-48d5-8271-a22b94d4259e" width="100px;" alt="Foto de Lucas"/><br>
        <sub>
          <b>Lucas Barcelar</b>
        </sub>
      </a>
    </td>
    <td align="center">
      <a href="#">
        <img src="https://github.com/user-attachments/assets/23751a4b-fb08-4098-883c-37fdef49af20" width="100px;" alt="Foto do Tiago"/><br>
        <sub>
          <b>Tiago Monteiro</b>
        </sub>
      </a>
    </td>
    <td align="center">
      <a href="#">
        <img src="https://github.com/user-attachments/assets/00023a53-7479-4150-ae30-8a6ae17737ed" width="100px;" alt="Foto de Tómas"/><br>
        <sub>
          <b>Tomás Brandão</b>
        </sub>
      </a>
    </td>
    <td align="center">
      <a href="#">
        <img src="https://github.com/user-attachments/assets/a9410220-2828-4fd9-8304-dc3e968e68c6" width="100px;" alt="Foto de Thiago"/><br>
        <sub>
          <b>Thiago Pinto</b>
        </sub>
      </a>
    </td>
  </tr>
</table>
